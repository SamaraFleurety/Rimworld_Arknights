﻿using System;
using System.Reflection;
using HarmonyLib;
using RimWorld;
using Verse;
using UnityEngine;

namespace yayoCombat
{
	//[HarmonyPatch(typeof(Projectile))]
	//[HarmonyPatch("StartingTicksToImpact", PropertyMethod.Getter)]
	
	[HarmonyPatch(typeof(Projectile))]
	[HarmonyPatch("StartingTicksToImpact", MethodType.Getter)]
	static class yayoStartingTicksToImpact
    {
        public static bool Prefix(Projectile __instance, ref float __result)
        {
            Vector3 origin = Traverse.Create(__instance).Field("origin").GetValue<Vector3>();
            Vector3 destination = Traverse.Create(__instance).Field("destination").GetValue<Vector3>();

			//float num = (this.origin - this.destination).magnitude / this.def.projectile.SpeedTilesPerTick;
			float speed = __instance.def.projectile.SpeedTilesPerTick * yayoCombat.bulletSpeed;
			if (speed >= yayoCombat.maxBulletSpeed * 0.01f)
			{
				speed = yayoCombat.maxBulletSpeed * 0.01f;
			}

			float num = (origin - destination).magnitude / speed;

			

            if (num <= 0f)
            {
				num = 0.001f;
			}
			

            __result = num;
            return false;
        }
    }
    

}
